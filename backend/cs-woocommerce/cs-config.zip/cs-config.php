<?php

/**
 * woocommerce custom settings
 * and hooks
 */
function cs_woocommerce_enabled() {
    if (class_exists('WooCommerce')) {
        return true;
    }
    return false;
}

/**
 * check if the plugin is enabled, 
 * otherwise stop the script
 */
if (!cs_woocommerce_enabled()) {
    return false;
}
/**
 * woocommerce support theme
 */
add_theme_support('woocommerce');

add_filter('woocommerce_enqueue_styles', '__return_false');
add_action('wp_enqueue_scripts', 'child_manage_woocommerce_styles', 99);

function child_manage_woocommerce_styles() {
    //remove generator meta tag
    remove_action('wp_head', array($GLOBALS['woocommerce'], 'generator'));
    //first check that woo exists to prevent fatal errors
    if (function_exists('is_woocommerce')) {
        //dequeue scripts and styles
        if (!is_woocommerce() && !is_cart() && !is_checkout() && !is_shop()) {
            wp_dequeue_script('wc_price_slider');
            wp_dequeue_script('wc-single-product');
            //wp_dequeue_script('wc-add-to-cart');
            wp_dequeue_script('wc-cart-fragments');
            wp_dequeue_script('wc-checkout');
            wp_dequeue_script('wc-add-to-cart-variation');
            wp_dequeue_script('wc-single-product');
            //wp_dequeue_script('wc-cart');
            wp_dequeue_script('wc-chosen');
            //wp_dequeue_script('woocommerce');
            wp_dequeue_script('prettyPhoto');
            wp_dequeue_script('prettyPhoto-init');
            //wp_dequeue_script('jquery-blockui');
            wp_dequeue_script('jquery-placeholder');
            wp_dequeue_script('fancybox');
            wp_dequeue_script('jqueryui');
        }
    }
}

/**
 * remove woo defaults
 */
function cs_shop_title() {
    $title = '';
    return $title;
}

add_filter('woocommerce_show_page_title', 'cs_shop_title');
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);

/**
 * Define image sizes
 */
$var_arrays = array('pagenow');
$congig_global_vars = CS_TRAVELADVISOR_GLOBALS()->globalizing($var_arrays);
extract($congig_global_vars);
if (is_admin() && isset($_GET['activated']) && $pagenow == 'themes.php')
    add_action('init', 'cs_woocommerce_image_dimensions', 1);

function cs_woocommerce_image_dimensions() {
    $catalog = array(
        'width' => '350', // px
        'height' => '350', // px
        'crop' => 1 // true
    );
    $single = array(
        'width' => '350', // px
        'height' => '350', // px
        'crop' => 1 // true
    );
    $thumbnail = array(
        'width' => '350', // px
        'height' => '350', // px
        'crop' => 1 // false
    );
    // Image sizes
    update_option('shop_catalog_image_size', $catalog); // Product category thumbs
    update_option('shop_single_image_size', $single); // Single product image
    update_option('shop_thumbnail_image_size', $thumbnail); // Image gallery thumbs
}

/**
 * removing shop default title
 */
function cs_woocommerce_shop_title() {
    $cs_shop_title = '';
    return $cs_shop_title;
}

add_filter('woocommerce_show_page_title', 'cs_woocommerce_shop_title');

/**
 * adding add to cart 
 * custom text
 */
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);

function cs_loop_add_to_cart() {
    global $product;
        echo '<div class="product-action-button">';
    echo apply_filters('woocommerce_loop_add_to_cart_link', sprintf('<a href="%s" rel="nofollow" data-product_id="%s" data-product_sku="%s" data-quantity="%s" class="cs-color btn btn-flat button csborder-color add-to-cart-button %s product_type_%s">%s</a>', esc_url($product->add_to_cart_url()), esc_attr($product->id), esc_attr($product->get_sku()), esc_attr(isset($quantity) ? $quantity : 1 ), $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '', esc_attr($product->product_type), 'Add to cart'), $product);
        echo '</div>';
    
}

/**
 * adding flash sale
 * custom text
 */
remove_action('woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10);
add_filter('woocommerce_sale_flash', 'cs_sale_flash_icon', 10, 3);

function cs_sale_flash_icon() {
    $icon = '<span class="featured-product"><i class="icon-star"></i></span>';
    echo cs_allow_special_char($icon);
}

/**
 * Product single page
 * customize Title
 */
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
add_filter('woocommerce_single_product_summary', 'cs_single_product_title', 5);

function cs_single_product_title() {
    $cs_prod_sale = get_post_meta(get_the_id(), '_stock_status', true);
    if ($cs_prod_sale == 'instock') {
        echo '<p><i class="icon-check-circle cs-color"></i>'.__('Avaiability', 'traveladvisor').': <span class="cs-color">'.__('in stock', 'traveladvisor').'</span></p>';
    } else {
        echo '<p><i class="icon-check-circle cs-color"></i>'.__('Avaiability', 'traveladvisor').': <span class="cs-color">'.__('out of stock', 'traveladvisor').'</span></p>';
    }
}

/**
 * removing product image dimensions
 */
add_filter('post_thumbnail_html', 'cs_remove_thumbnail_dimensions', 10, 3);

function cs_remove_thumbnail_dimensions($html, $post_id, $post_image_id) {
    $html = preg_replace('/(width|height)=\"\d*\"\s/', "", $html);
    return $html;
}
