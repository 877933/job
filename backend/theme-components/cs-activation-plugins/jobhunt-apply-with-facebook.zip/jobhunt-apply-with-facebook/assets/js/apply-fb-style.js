jQuery(document).ready(function ($) {
	jQuery(".applyauto").click();
});